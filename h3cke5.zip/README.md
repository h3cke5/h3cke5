# Frazix Website V2 (beta)

Demo - https://frazix.is-a.dev/Frazix2.0/